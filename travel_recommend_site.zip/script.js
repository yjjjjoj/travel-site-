function recommend() {
  const season = document.getElementById('season').value;
  const style = document.getElementById('style').value;
  const result = document.getElementById('result');

  const recommendations = {
    spring: {
      nature: "제주도 유채꽃 드라이브 🌼",
      city: "경주의 벚꽃길 🌸",
      healing: "전주 한옥마을에서의 산책 🍵",
      adventure: "지리산 둘레길 트레킹 🥾"
    },
    summer: {
      nature: "동해안 해수욕장 🏖️",
      city: "부산 광안리 밤바다 🌃",
      healing: "남해 힐링 펜션 🌿",
      adventure: "한탄강 래프팅 🛶"
    },
    autumn: {
      nature: "설악산 단풍 산책 🍁",
      city: "서울 북촌한옥마을 가을 산책 🏙️",
      healing: "강릉 바다명상 여행 🌊",
      adventure: "내장산 암벽등반 🧗‍♀️"
    },
    winter: {
      nature: "강원도 눈꽃 산행 ❄️",
      city: "서울 크리스마스 마켓 🎄",
      healing: "온천과 스파 여행 ♨️",
      adventure: "하이원 스키장 스키 여행 🎿"
    }
  };

  const message = recommendations[season][style];
  result.innerHTML = `🌟 추천 여행지: <strong>${message}</strong>`;
}
